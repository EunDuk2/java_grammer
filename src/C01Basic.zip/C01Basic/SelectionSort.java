package C01Basic;

import java.util.Arrays;

// 선택 정렬 알고리즘
public class SelectionSort {
    public static void main(String[] args) {
        int[] arr = {1, 2, 3};


    }

    // 배열이랑 인덱스 2개 받아서, 값 위치 바꿔서 반환
    static int[] switched(int[] arr, int startIndex, int endIndex) {
        int temp = arr[startIndex];
        arr[startIndex] = arr[endIndex];
        arr[endIndex] = temp;

        return arr;
    }

    // 배열이랑 시작 인덱스 받아서, 최소값 인덱스 반환
    static int findMinIndex(int[] arr, int startIndex) {
        
    }


}
